package acsse.csc2a.fantasy.model;

import java.io.Serializable;

public class Player implements Serializable, Comparable<Player>
{
	
	String PLAYER_PLAYER_ID; //the unique playerID of the Player (String)
	String PLAYER_ROLE; //the role of the Player (String)
	int PLAYER_PROWESS; //the prowess of the Player (int)
	double PLAYER_MANA; //the mana of the Player (double)
	
	public Player(String pLAYER_PLAYER_ID, 
			String pLAYER_ROLE, int pLAYER_PROWESS, double pLAYER_MANA)
	{
		PLAYER_PLAYER_ID = pLAYER_PLAYER_ID;
		PLAYER_ROLE = pLAYER_ROLE;
		PLAYER_PROWESS = pLAYER_PROWESS;
		PLAYER_MANA = pLAYER_MANA;
	}
	
	public String getPLAYER_PLAYER_ID() {
		return PLAYER_PLAYER_ID;
	}
	
	public void setPLAYER_PLAYER_ID(String pLAYER_PLAYER_ID) {
		PLAYER_PLAYER_ID = pLAYER_PLAYER_ID;
	}
	
	public String getPLAYER_ROLE() {
		return PLAYER_ROLE;
	}
	
	public void setPLAYER_ROLE(String pLAYER_ROLE) {
		PLAYER_ROLE = pLAYER_ROLE;
	}
	
	public int getPLAYER_PROWESS() {
		return PLAYER_PROWESS;
	}
	
	public void setPLAYER_PROWESS(int pLAYER_PROWESS) {
		PLAYER_PROWESS = pLAYER_PROWESS;
	}
	
	public double getPLAYER_MANA() {
		return PLAYER_MANA;
	}
	
	public void setPLAYER_MANA(double pLAYER_MANA) {
		PLAYER_MANA = pLAYER_MANA;
	}

	
	@Override
	public int compareTo(Player o)
	{
		
		return 0;
	}
	
}
