package acsse.csc2a.fantasy.file;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import acsse.csc2a.fantasy.model.Player;

public class PlayerFileHandler
{
	
	public static ArrayList<Player> readPlayerData(File handle)
	{
		int ITEM_COUNT = 0; //Number of Players in the file (int)
		ArrayList<Player> Players = null;
		
		try(FileInputStream fileInputStream = new FileInputStream(handle);
			BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
			ObjectInputStream objectInputStream = new ObjectInputStream(bufferedInputStream);)
		{
			while(objectInputStream.available() > 0)
			{
				ITEM_COUNT = objectInputStream.readInt();
				Player tempPlayer = (Player) objectInputStream.readObject();
				if(tempPlayer instanceof Player)
				{
					Players.add(tempPlayer);
				}
				else {
					System.err.println("INVALID OBJECT!");
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Players;
		
	}
	
	public static void writePlayerObj(File handle, ArrayList<Player> players)
	{
		try(FileOutputStream fileOutputStream = new FileOutputStream(handle);
				BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(bufferedOutputStream);)
			{
				objectOutputStream.writeInt(players.size());
				for (Player player : players)
				{
					objectOutputStream.writeObject(player);
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
