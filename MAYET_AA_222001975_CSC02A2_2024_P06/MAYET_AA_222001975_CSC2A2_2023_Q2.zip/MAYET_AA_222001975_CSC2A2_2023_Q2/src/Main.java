import java.io.File;
import java.util.ArrayList;
import acsse.csc2a.fantasy.file.PlayerFileHandler;
import acsse.csc2a.fantasy.model.Player;

public class Main {
	
	public static void main(String[] args) {
		String[] fileStrings = {"data/fantasy-small.dat", 
				"data/fantasy-medium.dat", "data/fantasy-large.dat"};
		
		PlayerFileHandler fileHandler = new PlayerFileHandler();
		
		for (String string : fileStrings)
		{
			File handlerFile = new File(string);
			//ArrayList<Player> players = fileHandler.readPlayerData(handlerFile);
			
		}
		
	}
}