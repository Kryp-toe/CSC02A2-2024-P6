package acsse.csc2a.supermarket.model;

public enum EDietType {
	VEGETARIAN,
	LACTOFREE,
	MEAT,
	VEGAN;
}