package acsse.csc2a.supermarket.file;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import acsse.csc2a.supermarket.model.CannedFood;
import acsse.csc2a.supermarket.model.EDietType;
import acsse.csc2a.supermarket.model.FrozenFood;
import acsse.csc2a.supermarket.model.Store;

public class FoodFileHandler
{
	public Store readStore(String fileName)
	{
		Store store = new Store();
		
		try
		{
			File handlerFile = new File(fileName);
			Scanner txtOut = new Scanner(handlerFile);
			
			while (txtOut.hasNext())
			{
				String lineString = txtOut.nextLine();
				
				// [A-Z]{4}[/d]{2}[A-Z]{2}/t[./*]/t[/d][.][/d]
				String regEx_CannedFoodString = "[A-Z]{4}[//d]{2}[A-Z]{2}//t[.//*]"
						+ "//t[//d][.][//d]";

				/* [A-Z]{4}[/d]{2}[A-Z]{2}/t[./*]
				 *	/t([VEGETARIAN|LACTOFREE|MEAT|VEGAN])/t[/d]
				 */
				String regEx_FrozenFoodString = "[A-Z]{4}[//d]{2}[A-Z]{2}//t[.//*]"
						+ "//t([VEGETARIAN|LACTOFREE|MEAT|VEGAN])//t[//d]";

				Pattern regEx_CannedFoodPattern = Pattern.compile(regEx_CannedFoodString);
				Matcher regEx_CannedFoodMatch = regEx_CannedFoodPattern.matcher(lineString);
				
				Pattern regEx_FrozenFoodPattern = Pattern.compile(regEx_FrozenFoodString);
				Matcher regEx_FrozenFoodMatch = regEx_FrozenFoodPattern.matcher(lineString);
				
				if(regEx_CannedFoodMatch.matches())
				{
					String barcodeString = txtOut.next();
					String qualityString = txtOut.next();
					double weight = txtOut.nextDouble();
					
					CannedFood cannedFood = new CannedFood(barcodeString, 
							qualityString, weight);
					store.AddToFoods(cannedFood);
					
				}else if(regEx_FrozenFoodMatch.matches())
				{
					String barcodeString = txtOut.next();
					String qualityString = txtOut.next();
					EDietType dietType = EDietType.valueOf(txtOut.next());
					int temp = txtOut.nextInt();
					
					FrozenFood frozenFood = new FrozenFood(barcodeString, 
							qualityString, temp, dietType);
					store.AddToFoods(frozenFood);
					
				}else {
					System.err.println("INVALID REGEX! COULD NOT READ LINE.");
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return store;
	}
}
