import java.util.ArrayList;
import acsse.csc2a.supermarket.file.FoodFileHandler;
import acsse.csc2a.supermarket.model.*;

public class Main {
	public static void main(String[] args) {
		String [] fileStrings = {"data/supermarket-small.txt",
		 "data/supermarket-medium.txt","data/supermarket-large.txt"};
		
		FoodFileHandler readFile = new FoodFileHandler();
		for (String file : fileStrings) {
			System.out.println("READING FROM: " + file);
			Store store = readFile.readStore(file);
			ArrayList<Food> tempFoods = store.GetList();
			if (tempFoods != null) {
				for (Food f : tempFoods) {
					if(f instanceof CannedFood)
					{
						System.out.println(f);
					}else if(f instanceof FrozenFood)
					{
						System.err.println(f);
					}
				}
			}
		}
		
	}
}
